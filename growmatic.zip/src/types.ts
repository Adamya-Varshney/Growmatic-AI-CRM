export type BusinessType = string;

export interface BusinessProfile {
  name: string;
  type: BusinessType;
  city: string;
  language: string;
}

export type LeadStatus = 'New' | 'Hot' | 'Contacted' | 'Closed';
export type LeadSource = 'WhatsApp' | 'Google Maps' | 'Instagram' | 'In-Store';

export interface Lead {
  id: string;
  name: string;
  phone: string;
  source: LeadSource;
  status: LeadStatus;
  productInterest: string;
  dateAdded: string;
  notes?: string;
}

export interface CampaignCreative {
  id: string;
  title: string;
  businessType: BusinessType;
  platform: 'WhatsApp' | 'Instagram' | 'Facebook';
  textCopy: string;
  category: string;
}

export interface RoiEstimation {
  adSpend: number;
  printingCost: number;
  addedSalesCount: number;
  avgOrderValue: number;
}
