import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, Zap, MessageSquare, Check, ArrowRight } from 'lucide-react';
import { BusinessProfile } from '../types';

interface LeadsTabProps {
  profile: BusinessProfile;
}

interface VisualLead {
  id: string;
  name: string;
  intent: 'High' | 'Medium' | 'Archived';
  danceStyle: string;
  batchPreference: string;
  city?: string;
  source: string;
  timeAgo: string;
  initials: string;
  statusTag?: string; // e.g. "Follow up due" or similar custom details
}

export default function LeadsTab({ profile }: LeadsTabProps) {
  const navigate = useNavigate();
  // Pre-seeded exactly 4 customized premium lead cards requested by the user
  const [leadsList, setLeadsList] = useState<VisualLead[]>([
    {
      id: 'l1',
      name: 'Priya Rajesh',
      intent: 'High',
      danceStyle: 'Hip-hop',
      batchPreference: 'Weekend',
      city: 'Mumbai',
      source: 'Via Creative A',
      timeAgo: '2hr ago',
      initials: 'PR'
    },
    {
      id: 'l2',
      name: 'Sneha K.',
      intent: 'High',
      danceStyle: 'Hip-hop',
      batchPreference: 'Weekend',
      city: 'Thane',
      source: 'Via Creative A',
      timeAgo: '4hr ago',
      initials: 'SK'
    },
    {
      id: 'l3',
      name: 'Amit M.',
      intent: 'Medium',
      danceStyle: 'Bollywood',
      batchPreference: 'Weekday',
      city: 'Pune',
      source: 'Via Creative B',
      timeAgo: 'Follow up due', // or amber status tag
      initials: 'AM',
      statusTag: 'Follow up due'
    },
    {
      id: 'l4',
      name: 'Rahul K.',
      intent: 'Archived',
      danceStyle: 'No response',
      batchPreference: '48 hours',
      city: '',
      source: 'Via Creative A',
      timeAgo: 'Yesterday',
      initials: 'RK'
    }
  ]);

  const [activeFilter, setActiveFilter] = useState<'All' | 'High Intent' | 'Follow Up'>('All');
  const [nudgeSent, setNudgeSent] = useState(false);

  // Filter Logic
  const filteredLeads = leadsList.filter(lead => {
    if (activeFilter === 'All') return true;
    if (activeFilter === 'High Intent') return lead.intent === 'High';
    if (activeFilter === 'Follow Up') return lead.intent === 'Medium'; // Amit M. is the only Medium/Follow up lead
    return true;
  });

  const handleSendNudge = () => {
    setNudgeSent(true);
    setTimeout(() => {
      setNudgeSent(false);
    }, 3000);
  };

  return (
    <div className="flex flex-col gap-4 font-sans">
      
      {/* 2. Filter tabs below header - three pill shaped tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => setActiveFilter('All')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activeFilter === 'All'
              ? 'bg-[#4F46E5] text-white shadow-sm'
              : 'bg-white text-gray-500 border border-[#F0F0EE] hover:bg-gray-50'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveFilter('High Intent')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activeFilter === 'High Intent'
              ? 'bg-[#4F46E5] text-white shadow-sm'
              : 'bg-white text-gray-500 border border-[#F0F0EE] hover:bg-gray-50'
          }`}
        >
          High Intent
        </button>
        <button
          onClick={() => setActiveFilter('Follow Up')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activeFilter === 'Follow Up'
              ? 'bg-[#4F46E5] text-white shadow-sm'
              : 'bg-white text-gray-500 border border-[#F0F0EE] hover:bg-gray-50'
          }`}
        >
          Follow Up
        </button>
      </div>

      {/* 3. A new lead alert banner - light indigo background, lightning bolt icon */}
      <div className="bg-[#EEF2FF] border border-[#E0E7FF] rounded-xl p-3 flex items-center gap-2.5 shadow-xs">
        <div className="p-1.5 bg-[#4F46E5]/10 text-[#4F46E5] rounded-lg shrink-0">
          <Zap size={15} className="fill-[#4F46E5]" strokeWidth={2.5} />
        </div>
        <p className="text-[11px] font-bold text-indigo-950 font-sans tracking-tight">
          8 new leads qualified today
        </p>
      </div>

      {/* 4 & 5. Lead Cards */}
      <div className="flex flex-col gap-3">
        {filteredLeads.map((lead) => {
          // Intent styling mapping
          let leftBorderColor = 'border-l-gray-400';
          let dotColor = 'bg-gray-400';
          let badgeStyle = 'bg-gray-100 text-gray-600 border border-gray-200';
          let cardStyle = 'bg-white border border-[#F0F0EE] shadow-xs rounded-xl p-4 flex flex-col gap-2.5 transition-all relative';

          if (lead.intent === 'High') {
            leftBorderColor = 'border-l-emerald-500';
            dotColor = 'bg-emerald-500';
            badgeStyle = 'bg-emerald-50 text-emerald-700 border border-emerald-100';
          } else if (lead.intent === 'Medium') {
            leftBorderColor = 'border-l-[#F59E0B]';
            dotColor = 'bg-[#F59E0B]';
            badgeStyle = 'bg-amber-50 text-amber-700 border border-amber-100';
          }

          if (lead.intent === 'Archived') {
            cardStyle += ' opacity-60 grayscale-[15%]';
          }

          return (
            <div 
              key={lead.id} 
              onClick={() => navigate('/lead-detail')}
              className={`${cardStyle} border-l-4 ${leftBorderColor} hover:shadow-md cursor-pointer`}
            >
              {/* Card Header row */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {/* Initials circular avatar */}
                  <div className="h-9 w-9 rounded-full bg-indigo-50 border border-indigo-100 text-[#4F46E5] font-bold text-xs uppercase flex items-center justify-center font-display shrink-0 shadow-xs">
                    {lead.initials}
                  </div>
                  
                  {/* Name and State Indicator Dot */}
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-gray-900 font-sans">
                        {lead.name}
                      </span>
                      <span className={`h-2 w-2 rounded-full ${dotColor}`} />
                    </div>
                    {/* Dance interest / one line list */}
                    <p className="text-[11px] text-gray-500 font-medium">
                      {lead.danceStyle}
                      {lead.batchPreference ? ` • ${lead.batchPreference}` : ''}
                      {lead.city ? ` • ${lead.city}` : ''}
                    </p>
                  </div>
                </div>

                {/* Intent score badge */}
                <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full ${badgeStyle} font-display tracking-wider`}>
                  {lead.intent}
                </span>
              </div>

              {/* Badges footer row */}
              <div className="flex items-center gap-2 border-t border-[#F0F0EE]/60 pt-2 text-[10px]">
                <span className="bg-slate-50 border border-slate-100 text-gray-400 font-semibold px-2 py-0.5 rounded-md">
                  {lead.source}
                </span>
                <span className="bg-slate-50 border border-slate-100 text-gray-450 font-medium px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Clock size={10} className="text-gray-400" />
                  {lead.timeAgo}
                </span>
                
                {lead.statusTag && (
                  <span className="bg-amber-50 border border-amber-100 text-[#F59E0B] font-bold px-2 py-0.5 rounded-md ml-auto text-[9px] uppercase tracking-wider">
                    {lead.statusTag}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* 6. A follow-up reminder banner at the bottom */}
      <div className="bg-amber-50 border border-amber-100 rounded-xl p-3.5 flex items-center justify-between gap-3 shadow-xs mt-2 relative overflow-hidden">
        <div className="flex items-start gap-2.5">
          <div className="p-1.5 bg-[#F59E0B]/10 text-[#F59E0B] rounded-lg mt-0.5 shrink-0">
            <Clock size={15} strokeWidth={2.5} />
          </div>
          <div>
            <p className="text-[11px] font-bold text-amber-950 font-display uppercase tracking-wider leading-none">
              Inquiry Pending
            </p>
            <p className="text-[10px] text-amber-900 mt-1 leading-snug font-medium font-sans">
              Amit M. has not replied in 24 hours. Send a nudge.
            </p>
          </div>
        </div>

        {nudgeSent ? (
          <button
            className="bg-emerald-600 text-white text-[10px] font-bold py-1.5 px-3 rounded-lg flex items-center gap-1 shrink-0 transition-all font-sans cursor-default"
          >
            <Check size={11} strokeWidth={3} />
            <span>Sent</span>
          </button>
        ) : (
          <button
            onClick={handleSendNudge}
            className="bg-[#F59E0B] hover:bg-amber-600 text-white text-[10px] font-bold py-1.5 px-3 rounded-lg transition-all font-sans shrink-0 cursor-pointer shadow-sm"
          >
            Send nudge
          </button>
        )}
      </div>

    </div>
  );
}
