import React from 'react';
import { Home, Users, TrendingUp, Sparkles, Building2, MapPin, ArrowRight, CheckCircle2, Zap, Palette, Edit } from 'lucide-react';
import { BusinessProfile } from '../types';

interface HomeTabProps {
  profile: BusinessProfile;
  setProfile: (p: BusinessProfile) => void;
  onNavigate: (tab: string) => void;
  leadsCount: { total: number; hot: number };
}

export default function HomeTab({ profile, setProfile, onNavigate, leadsCount }: HomeTabProps) {
  const [showSettings, setShowSettings] = React.useState(false);
  const [editedName, setEditedName] = React.useState(profile.name);
  const [editedType, setEditedType] = React.useState(profile.type);
  const [editedCity, setEditedCity] = React.useState(profile.city);
  const [actionDone, setActionDone] = React.useState(false);

  const saveProfile = () => {
    setProfile({
      name: editedName || 'IDALS',
      type: editedType || 'Online Dance Education',
      city: editedCity || 'Mumbai',
      language: 'English'
    });
    setShowSettings(false);
  };

  return (
    <div className="flex flex-col gap-5 pb-6">
      
      {/* Modern High-End Greeting */}
      <div>
        <span className="text-[10px] font-bold text-primary tracking-widest uppercase">
          Growmatic Dashboard
        </span>
        <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight font-display mt-0.5">
          Good morning, Rahul
        </h2>
        <p className="text-xs text-gray-400 mt-1 leading-relaxed">
          Your automated digital co-pilot is active and optimizing.
        </p>
      </div>

      {/* Grid: 3 Stat Cards in a Row */}
      <div className="grid grid-cols-3 gap-2.5">
        {/* Stat 1: High Intent (green) */}
        <div className="bg-white p-3 rounded-xl border border-[#F0F0EE] shadow-xs flex flex-col justify-between">
          <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 block leading-none">High Intent</span>
          <div className="mt-2.5">
            <div className="text-xl font-extrabold text-emerald-600 leading-none font-display">
              {leadsCount.hot}
            </div>
            <div className="text-[8px] text-gray-450 mt-1 font-semibold">Active hot pipeline</div>
          </div>
        </div>

        {/* Stat 2: Total Leads (indigo) */}
        <div className="bg-[#FAF9FF] p-3 rounded-xl border border-indigo-100 shadow-xs flex flex-col justify-between">
          <span className="text-[9px] font-bold uppercase tracking-wider text-[#4F46E5] block leading-none">Total Leads</span>
          <div className="mt-2.5">
            <div className="text-xl font-extrabold text-[#4F46E5] leading-none font-display">
              {leadsCount.total}
            </div>
            <div className="text-[8px] text-indigo-400 mt-1 font-semibold">Registered roster</div>
          </div>
        </div>

        {/* Stat 3: ROAS (teal) */}
        <div className="bg-white p-3 rounded-xl border border-[#F0F0EE] shadow-xs flex flex-col justify-between">
          <span className="text-[9px] font-bold uppercase tracking-wider text-teal-600 block leading-none">ROAS Est.</span>
          <div className="mt-2.5">
            <div className="text-xl font-extrabold text-teal-600 leading-none font-display">
              5.4x
            </div>
            <div className="text-[8px] text-emerald-500 mt-1 font-semibold">Up 15% this Q</div>
          </div>
        </div>
      </div>

      {/* AI Recommendation Slot */}
      <div className="bg-[#EEF2FF] border-l-4 border-[#4F46E5] rounded-xl p-4 flex flex-col border border-indigo-150/50 shadow-xs relative overflow-hidden">
        <div className="absolute top-0 right-0 p-3 opacity-5 pointer-events-none text-primary">
          <Zap size={64} className="fill-primary" />
        </div>

        <div className="flex items-center gap-1 text-[#4F46E5] font-bold text-[9px] uppercase tracking-wider">
          <Zap size={11} className="fill-[#4F46E5]" />
          <span>Today's recommendation</span>
        </div>

        <h4 className="text-xs font-bold text-gray-900 mt-2.5 leading-relaxed font-sans">
          Launch a target-matched outreach sequence for students inquiring about Dance Teacher Certifications.
        </h4>

        <p className="text-[10px] text-gray-500 mt-1.5 font-medium">
          Estimated Impact: <span className="text-emerald-600 font-bold">+35% CTR</span> and average increase in closed applications this week.
        </p>

        {actionDone ? (
          <div className="mt-3 bg-emerald-50 border border-emerald-100 text-emerald-800 p-2 text-center text-[10px] font-bold rounded-lg animate-fade-in">
            ✓ Done! Sequence initiated and copies dispatched to Creative Hub.
          </div>
        ) : (
          <div className="mt-3.5 flex flex-col gap-2">
            <button 
              onClick={() => {
                setActionDone(true);
                setTimeout(() => onNavigate('creative'), 1200);
              }}
              className="w-full bg-[#4F46E5] hover:bg-indigo-700 text-white text-[11px] font-bold py-2 rounded-lg hover:bg-opacity-95 shadow-sm cursor-pointer transition-all text-center"
            >
              Do it for me
            </button>
            <button
              onClick={() => {
                setActionDone(true);
              }}
              className="text-center text-[10px] font-bold text-[#4F46E5] hover:underline py-1 transition-all"
            >
              I will do it myself
            </button>
          </div>
        )}
      </div>

      {/* Business Profile Card */}
      <div className="bg-white rounded-xl border border-[#F0F0EE] shadow-xs p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-50 text-primary rounded-lg">
              <Building2 size={15} />
            </div>
            <span className="text-[10px] font-bold uppercase text-gray-400 tracking-wider">Business Profile</span>
          </div>
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="text-[11px] font-bold text-primary hover:underline flex items-center gap-1 transition-all cursor-pointer"
          >
            <Edit size={10} />
            <span>Edit Profile</span>
          </button>
        </div>

        <div className="grid grid-cols-3 gap-1 pt-1 text-xs">
          <div>
            <span className="block text-[9px] font-bold text-gray-400 uppercase leading-none">Business</span>
            <span className="text-xs font-bold text-gray-800 mt-1 block font-sans">{profile.name}</span>
          </div>
          <div>
            <span className="block text-[9px] font-bold text-gray-400 uppercase leading-none">Type</span>
            <span className="text-xs font-semibold text-gray-800 mt-1 block font-sans truncate">{profile.type}</span>
          </div>
          <div>
            <span className="block text-[9px] font-bold text-gray-400 uppercase leading-none">Location</span>
            <span className="text-xs font-semibold text-gray-800 mt-1 block font-sans">{profile.city}</span>
          </div>
        </div>
      </div>

      {/* Profile Form (Collapsible) */}
      {showSettings && (
        <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm animate-fade-in space-y-3">
          <h3 className="text-xs font-bold text-gray-800 flex items-center gap-2">
            <Building2 size={14} className="text-primary" />
            Update Business Profile Settings
          </h3>
          <div className="space-y-3">
            <div>
              <label className="block text-[9px] font-bold uppercase text-gray-400 mb-1">Business Name</label>
              <input 
                type="text" 
                value={editedName} 
                onChange={(e) => setEditedName(e.target.value)}
                placeholder="e.g. IDALS"
                className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg outline-none focus:border-primary text-gray-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[9px] font-bold uppercase text-gray-400 mb-1">Business Type</label>
                <input 
                  type="text" 
                  value={editedType} 
                  onChange={(e) => setEditedType(e.target.value)}
                  placeholder="e.g. Online Dance Education"
                  className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg outline-none focus:border-primary text-gray-800"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase text-gray-400 mb-1">City/Town</label>
                <input 
                  type="text" 
                  value={editedCity} 
                  onChange={(e) => setEditedCity(e.target.value)}
                  placeholder="e.g. Mumbai"
                  className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg outline-none focus:border-primary text-gray-800"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-1">
              <button 
                onClick={saveProfile}
                className="flex-1 bg-primary text-white text-xs font-bold py-2 rounded-lg hover:bg-opacity-95 shadow-xs cursor-pointer transition-all"
              >
                Save
              </button>
              <button 
                onClick={() => setShowSettings(false)}
                className="px-3 bg-slate-50 border border-slate-200 text-gray-500 text-xs font-semibold py-2 rounded-lg hover:bg-slate-100 transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recent Activity Pipeline */}
      <div className="space-y-2.5">
        <h4 className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
          Recent Activity
        </h4>
        
        <div className="bg-white rounded-xl divide-y divide-[#F0F0EE]/60 border border-[#F0F0EE] shadow-xs overflow-hidden">
          {/* Active 1 */}
          <div className="p-3.5 flex items-center gap-3 text-xs">
            <span className="p-1.5 bg-emerald-50 rounded-lg text-emerald-600 shrink-0">
              <Zap size={13} className="fill-emerald-600" />
            </span>
            <div className="flex-1">
              <p className="font-bold text-gray-800 leading-snug">Campaign broadcast dispatched</p>
              <span className="text-[9px] text-gray-400 font-medium font-sans">Sent via targeted API • 2 hours ago</span>
            </div>
          </div>

          {/* Active 2 */}
          <div className="p-3.5 flex items-center gap-3 text-xs">
            <span className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600 shrink-0">
              <Users size={13} />
            </span>
            <div className="flex-1">
              <p className="font-bold text-gray-800 leading-snug">New high-intent enquiry received</p>
              <span className="text-[9px] text-gray-400 font-medium font-sans">Instagram Match: Aarav Sharma • 5 hours ago</span>
            </div>
          </div>

          {/* Active 3 */}
          <div className="p-3.5 flex items-center gap-3 text-xs">
            <span className="p-1.5 bg-teal-50 rounded-lg text-teal-600 shrink-0">
              <CheckCircle2 size={13} />
            </span>
            <div className="flex-1">
              <p className="font-bold text-gray-800 leading-snug">Lead status marked Closed (Won)</p>
              <span className="text-[9px] text-gray-400 font-medium font-sans">Advanced Salsa Course enrollment • Yesterday</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
