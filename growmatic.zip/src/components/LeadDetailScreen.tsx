import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, Send, X, MessageSquare, Phone, MapPin, Share2 } from 'lucide-react';

interface LeadDetailScreenProps {
  onStatusUpdate?: (status: string) => void;
}

export default function LeadDetailScreen({ onStatusUpdate }: LeadDetailScreenProps) {
  const navigate = useNavigate();
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleConverted = () => {
    setIsSubmitting(true);
    triggerToast("🎉 Status Updated: Lead successfully marked as converted!");
    setTimeout(() => {
      setIsSubmitting(false);
      if (onStatusUpdate) onStatusUpdate('Converted');
      navigate('/leads');
    }, 1500);
  };

  const handleFollowUp = () => {
    triggerToast("💬 Follow-up message dispatched to Priya Rajesh on Telegram!");
  };

  const handleLost = () => {
    setIsSubmitting(true);
    triggerToast("📉 Status Updated: Lead marked as lost.");
    setTimeout(() => {
      setIsSubmitting(false);
      if (onStatusUpdate) onStatusUpdate('Lost');
      navigate('/leads');
    }, 1500);
  };

  return (
    <div className="min-h-full bg-[#FAF9F6] flex flex-col justify-between font-sans relative">
      
      {/* 1. Header — back arrow on left — title Lead Detail — no bottom navigation */}
      <header className="bg-white px-5 py-4 border-b border-[#F0F0EE] flex items-center justify-between shrink-0 shadow-[0_2px_4px_rgba(0,0,0,0.02)] z-20 font-sans">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/leads')}
            className="text-gray-500 hover:text-[#4F46E5] p-1 rounded-lg hover:bg-slate-50 transition-all cursor-pointer"
            id="lead-detail-back-btn"
          >
            <ArrowLeft size={20} strokeWidth={2.5} />
          </button>
          <span className="text-lg font-bold text-gray-800 tracking-tight font-display">
            Lead Detail
          </span>
        </div>
        <button 
          onClick={() => triggerToast("Lead details shared successfully!")}
          className="p-1.5 hover:bg-slate-100 rounded-lg transition-all text-gray-400 hover:text-gray-600 cursor-pointer"
        >
          <Share2 size={16} />
        </button>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-5 flex flex-col gap-5">
        
        {/* Loading Spinner Overlay */}
        {isSubmitting && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex flex-col items-center justify-center p-6 text-center">
            <div className="bg-white rounded-2xl p-6 shadow-xl flex flex-col items-center gap-4 max-w-[280px]">
              <span className="h-8 w-8 border-4 border-[#4F46E5] border-t-transparent rounded-full animate-spin" />
              <div className="text-xs font-bold text-gray-800">Updating lead pipeline status...</div>
            </div>
          </div>
        )}

        {/* 2. Lead profile section at top */}
        <div className="flex items-center justify-between bg-white border border-[#F0F0EE] p-4 rounded-2xl shadow-2xs">
          <div className="flex items-center gap-3">
            {/* Large circular avatar — 44px — indigo background — white initials PR */}
            <div id="lead-avatar" className="h-[44px] w-[44px] rounded-full bg-[#4F46E5] text-white flex items-center justify-center font-black text-sm select-none shadow-xs shrink-0 font-display">
              PR
            </div>
            {/* Next to avatar: Lead name Priya Rajesh in bold 16px — below name: phone number +91 98765 43210 and city Mumbai in grey 11px */}
            <div>
              <h2 className="text-base font-bold text-gray-900 tracking-tight font-sans leading-none">
                Priya Rajesh
              </h2>
              <p className="text-[11px] text-gray-400 mt-1 font-medium flex items-center gap-1">
                <span className="font-semibold text-gray-500 font-mono">+91 98765 43210</span>
                <span>•</span>
                <span className="flex items-center gap-0.5"><MapPin size={10} /> Mumbai</span>
              </p>
            </div>
          </div>

          {/* On the right side of the row: High intent badge — emerald green background — white text */}
          <span className="text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-emerald-500 text-white font-display tracking-wider shadow-2xs">
            High Intent
          </span>
        </div>

        {/* 3. Qualification summary card — light grey background — rounded corners — padding 12px */}
        <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-2.5xl p-4 flex flex-col gap-3 shadow-3xs">
          <div className="flex items-center justify-between border-b border-gray-200/60 pb-2">
            <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
              Qualification Summary
            </span>
            <span className="text-[9px] font-black tracking-wider text-[#4F46E5] uppercase bg-indigo-50 px-1.5 py-0.5 rounded-md leading-none">
              Verified
            </span>
          </div>

          {/* Five detail rows each showing label on left and value on right separated by a light border */}
          <div className="flex flex-col gap-2 font-sans">
            {/* Row 1: Dance style — Hip-hop */}
            <div className="flex items-center justify-between py-1.5 border-b border-gray-150/45 text-xs">
              <span className="text-gray-450 font-medium">Dance style</span>
              <span className="text-gray-800 font-bold">Hip-hop</span>
            </div>

            {/* Row 2: Batch preference — Weekend */}
            <div className="flex items-center justify-between py-1.5 border-b border-gray-150/45 text-xs">
              <span className="text-gray-450 font-medium">Batch preference</span>
              <span className="text-gray-800 font-bold">Weekend</span>
            </div>

            {/* Row 3: City — Mumbai */}
            <div className="flex items-center justify-between py-1.5 border-b border-gray-150/45 text-xs">
              <span className="text-gray-450 font-medium">City</span>
              <span className="text-gray-800 font-bold">Mumbai</span>
            </div>

            {/* Row 4: Response time — 2 minutes */}
            <div className="flex items-center justify-between py-1.5 border-b border-gray-150/45 text-xs">
              <span className="text-gray-450 font-medium">Response time</span>
              <span className="text-gray-800 font-bold text-emerald-600">2 minutes</span>
            </div>

            {/* Row 5: Source — Meta ad · Creative A */}
            <div className="flex items-center justify-between py-1.5 border-b border-gray-150/45 text-xs">
              <span className="text-gray-450 font-medium">Source</span>
              <span className="text-gray-800 font-bold text-[#4F46E5]">Meta ad · Creative A</span>
            </div>

            {/* Row 6: Captured via — Telegram bot */}
            <div className="flex items-center justify-between pt-1.5 text-xs">
              <span className="text-gray-450 font-medium">Captured via</span>
              <span className="text-gray-800 font-bold bg-[#E0F2FE] text-[#0369A1] px-1.5 py-0.5 rounded">
                Telegram bot
              </span>
            </div>
          </div>
        </div>

        {/* 4. Conversation transcript section */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider font-sans">
            Telegram Conversation
          </label>
          {/* A condensed preview box — grey background — showing truncated transcript text */}
          <div className="bg-slate-100/90 border border-slate-200/80 rounded-2xl p-4 flex flex-col gap-2.5">
            <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider">
              <MessageSquare size={11} />
              <span>Transcript Stream</span>
            </div>
            {/* Box looks like a condensed chat preview */}
            <div className="flex flex-col gap-2 font-mono text-[10.5px] leading-relaxed text-slate-700 bg-white/90 p-3 rounded-xl border border-slate-150 shadow-3xs">
              <div className="flex items-start gap-1">
                <span className="text-teal-600 font-bold uppercase tracking-wider shrink-0 text-[10px]">Bot:</span>
                <span className="text-gray-600">Which dance style interests you?</span>
              </div>
              <div className="flex items-start gap-1">
                <span className="text-[#4F46E5] font-bold uppercase tracking-wider shrink-0 text-[10px]">Priya:</span>
                <span className="text-gray-800 font-bold">Hip-hop!</span>
              </div>
              <div className="flex items-start gap-1">
                <span className="text-teal-600 font-bold uppercase tracking-wider shrink-0 text-[10px]">Bot:</span>
                <span className="text-gray-600">Weekday or weekend classes preferable?</span>
              </div>
              <div className="flex items-start gap-1">
                <span className="text-[#4F46E5] font-bold uppercase tracking-wider shrink-0 text-[10px]">Priya:</span>
                <span className="text-gray-800 font-bold">Weekends.</span>
              </div>
              <div className="flex items-start gap-1">
                <span className="text-teal-600 font-bold uppercase tracking-wider shrink-0 text-[10px]">Bot:</span>
                <span className="text-gray-600">Which city do you reside in currently?</span>
              </div>
              <div className="flex items-start gap-2">
                <div className="flex items-start gap-1">
                  <span className="text-[#4F46E5] font-bold uppercase tracking-wider shrink-0 text-[10px]">Priya:</span>
                  <span className="text-gray-800 font-bold">Mumbai.</span>
                </div>
              </div>
              <div className="border-t border-slate-100 pt-1.5 text-[10px] text-gray-450 italic flex items-center gap-1">
                <span>🤖 Bot: IDALS team will reach out to schedule batch 5...</span>
              </div>
            </div>
          </div>
        </div>

        {/* 5. Three action buttons stacked vertically */}
        <div className="flex flex-col gap-2.5 mt-2">
          {/* Button 1: Mark as converted — full width — teal background — white text */}
          <button
            onClick={handleConverted}
            className="w-full bg-[#0D9488] hover:bg-teal-700 text-white font-bold py-3 px-4 rounded-xl transition-all cursor-pointer shadow-sm text-xs uppercase tracking-wider flex items-center justify-center gap-2"
          >
            <Check size={14} strokeWidth={3} />
            <span>Mark as converted</span>
          </button>

          {/* Button 2: Send follow-up message — full width — deep indigo background — white text */}
          <button
            onClick={handleFollowUp}
            className="w-full bg-[#4F46E5] hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-all cursor-pointer shadow-sm text-xs uppercase tracking-wider flex items-center justify-center gap-2"
          >
            <Send size={12} strokeWidth={2.5} />
            <span>Send follow-up message</span>
          </button>

          {/* Button 3: Mark as lost — full width — transparent background — rose red border and text */}
          <button
            onClick={handleLost}
            className="w-full bg-transparent hover:bg-rose-50 border border-[#E11D48] text-[#E11D48] font-bold py-3 px-4 rounded-xl transition-all cursor-pointer text-xs uppercase tracking-wider flex items-center justify-center gap-2"
          >
            <X size={14} strokeWidth={2.5} />
            <span>Mark as lost</span>
          </button>
        </div>

      </div>

      {/* Floating notifications */}
      {toastMessage && (
        <div className="fixed bottom-[40px] left-1/2 -translate-x-1/2 bg-slate-900/95 backdrop-blur-xs text-white text-[10.5px] font-bold px-4 py-2.5 rounded-xl shadow-lg border border-slate-800 z-50 flex items-center gap-2 animate-bounce max-w-[280px]">
          <Check size={12} className="text-emerald-500 shrink-0" strokeWidth={3} />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
